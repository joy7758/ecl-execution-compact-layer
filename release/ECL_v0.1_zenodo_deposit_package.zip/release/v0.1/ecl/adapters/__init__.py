"""Trace adapters for ECL."""

