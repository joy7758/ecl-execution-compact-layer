"""Execution Compact Layer local artifact builder."""

__all__ = [
    "__version__",
]

__version__ = "0.1.0"

